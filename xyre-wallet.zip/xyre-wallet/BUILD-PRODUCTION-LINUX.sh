#!/bin/bash
set -u
cd "$(dirname "$0")"

printf '%s\n' "========================================" " XYRE Wallet - Production Builder" "========================================" ""

if ! command -v node >/dev/null 2>&1; then
  echo "Node.js is not installed."
  echo "Install Node.js 22 LTS from https://nodejs.org/ and run this file again."
  read -n 1 -s -r -p "Press any key to close..."
  exit 1
fi

if ! node -e 'const [M,m]=process.versions.node.split(".").map(Number); process.exit(M>20 || (M===20 && m>=19) ? 0 : 1)'; then
  echo "Node.js 20.19+ is required. Node.js 22 LTS is recommended."
  echo "Current version: $(node -v)"
  read -n 1 -s -r -p "Press any key to close..."
  exit 1
fi

echo "Preparing dependencies..."
npm install --include=optional || {
  echo "Dependency installation failed."
  read -n 1 -s -r -p "Press any key to close..."
  exit 1
}

echo
echo "Creating optimized production build..."
npm run release || {
  echo "Production build failed."
  read -n 1 -s -r -p "Press any key to close..."
  exit 1
}

echo
echo "Done. Opening the release folder..."
if command -v xdg-open >/dev/null 2>&1; then
  xdg-open release >/dev/null 2>&1 &
elif command -v gio >/dev/null 2>&1; then
  gio open release >/dev/null 2>&1 &
fi
echo "You can deploy release/xyre-wallet-web/ or xyre-wallet-web.zip"
echo
read -n 1 -s -r -p "Press any key to close..."
