@echo off
setlocal
cd /d "%~dp0"
title XYRE Wallet - Production Builder

echo ========================================
echo  XYRE Wallet - Production Builder
echo ========================================
echo.

where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is not installed.
  echo Install Node.js 22 LTS from https://nodejs.org/ and run this file again.
  echo.
  pause
  exit /b 1
)

node -e "const [M,m]=process.versions.node.split('.').map(Number); process.exit(M>20 || (M===20 && m>=19) ? 0 : 1)"
if errorlevel 1 (
  echo Node.js 20.19+ is required. Node.js 22 LTS is recommended.
  node -v
  echo.
  pause
  exit /b 1
)

echo Preparing dependencies...
call npm install --include=optional
if errorlevel 1 (
  echo.
  echo Dependency installation failed.
  pause
  exit /b 1
)

echo.
echo Creating optimized production build...
call npm run release
if errorlevel 1 (
  echo.
  echo Production build failed.
  pause
  exit /b 1
)

echo.
echo Done. Opening the release folder...
start "" explorer "%CD%\release"
echo You can deploy release\xyre-wallet-web\ or xyre-wallet-web.zip
echo.
pause
endlocal
