#!/bin/bash
set -u
cd "$(dirname "$0")"

echo "========================================"
echo "     XYRE Wallet - Linux"
echo "========================================"
echo

if ! command -v node >/dev/null 2>&1; then
  echo "Node.js is not installed."
  echo "Install Node.js 22 LTS from https://nodejs.org/ and run this file again."
  echo
  read -n 1 -s -r -p "Press any key to close..."
  exit 1
fi

if ! node -e 'const [M,m]=process.versions.node.split(".").map(Number); process.exit(M>20 || (M===20 && m>=19) ? 0 : 1)' ; then
  echo "Node.js 20.19+ is required. Node.js 22 LTS is recommended."
  echo "Current version: $(node -v)"
  echo
  read -n 1 -s -r -p "Press any key to close..."
  exit 1
fi

if [ ! -d node_modules ]; then
  echo "First launch: installing wallet dependencies..."
  npm install --include=optional || {
    echo
    echo "Dependency installation failed."
    read -n 1 -s -r -p "Press any key to close..."
    exit 1
  }
fi

echo
echo "Starting XYRE Wallet..."
echo "Your default browser will open automatically."
echo "Close this terminal window to stop the wallet."
echo
npm run start
