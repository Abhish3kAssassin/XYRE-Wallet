@echo off
setlocal
cd /d "%~dp0"
title XYRE Wallet

echo ========================================
echo        XYRE Wallet Launcher
echo ========================================
echo.

where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is not installed.
  echo Install Node.js 22 LTS from https://nodejs.org/ and run this file again.
  echo.
  pause
  exit /b 1
)

node -e "const [M,m]=process.versions.node.split('.').map(Number); process.exit(M>20 || (M===20 && m>=19) ? 0 : 1)"
if errorlevel 1 (
  echo Node.js 20.19+ is required. Node.js 22 LTS is recommended.
  node -v
  echo.
  pause
  exit /b 1
)

if not exist node_modules\ (
  echo First launch: installing wallet dependencies...
  call npm install --include=optional
  if errorlevel 1 (
    echo.
    echo Dependency installation failed.
    pause
    exit /b 1
  )
)

echo.
echo Starting XYRE Wallet...
echo Your default browser will open automatically.
echo Close this window to stop the wallet.
echo.
call npm run start

if errorlevel 1 (
  echo.
  echo The wallet server stopped with an error.
  pause
)
endlocal
