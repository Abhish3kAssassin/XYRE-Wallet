import http from 'node:http'
import { access, readFile, stat } from 'node:fs/promises'
import { extname, join, normalize } from 'node:path'
import { fileURLToPath } from 'node:url'
import { spawn } from 'node:child_process'

const HOST = '127.0.0.1'
const START_PORT = 5173
const ROOT = fileURLToPath(new URL('./dist/', import.meta.url))

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.ico': 'image/x-icon',
  '.webp': 'image/webp',
  '.woff2': 'font/woff2',
}

function securityHeaders() {
  return {
    'Cache-Control': 'no-store',
    'Content-Security-Policy': "default-src 'self'; connect-src 'self' wss://xrplcluster.com wss://s1.ripple.com wss://s2.ripple.com; img-src 'self' data:; style-src 'self'; script-src 'self'; font-src 'self' data:; object-src 'none'; base-uri 'self'; frame-ancestors 'none'",
    'Referrer-Policy': 'no-referrer',
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
  }
}

function safePath(urlPath) {
  const clean = decodeURIComponent((urlPath || '/').split('?')[0])
  const normalized = normalize(clean).replace(/^(\.\.[/\\])+/, '')
  const relative = normalized.replace(/^[/\\]+/, '')
  return join(ROOT, relative || 'index.html')
}

async function readAsset(urlPath) {
  let path = safePath(urlPath)
  try {
    const info = await stat(path)
    if (info.isDirectory()) path = join(path, 'index.html')
    return { path, data: await readFile(path) }
  } catch {
    // SPA fallback. Static asset misses still return index, which is fine for this app.
    const fallback = join(ROOT, 'index.html')
    return { path: fallback, data: await readFile(fallback) }
  }
}

function openBrowser(url) {
  if (process.env.NO_OPEN === '1') return

  let command
  let args

  if (process.platform === 'darwin') {
    command = 'open'
    args = [url]
  } else if (process.platform === 'win32') {
    command = 'cmd'
    args = ['/c', 'start', '', url]
  } else {
    command = 'xdg-open'
    args = [url]
  }

  const child = spawn(command, args, { detached: true, stdio: 'ignore' })
  child.on('error', () => {
    console.log(`Open this address in your browser: ${url}`)
  })
  child.unref()
}

async function listenOnAvailablePort(server, port = START_PORT) {
  return await new Promise((resolve, reject) => {
    const onError = (error) => {
      server.off('listening', onListening)
      if (error.code === 'EADDRINUSE' && port < START_PORT + 20) {
        resolve(listenOnAvailablePort(server, port + 1))
      } else {
        reject(error)
      }
    }
    const onListening = () => {
      server.off('error', onError)
      resolve(port)
    }
    server.once('error', onError)
    server.once('listening', onListening)
    server.listen(port, HOST)
  })
}

try {
  await access(join(ROOT, 'index.html'))
} catch {
  console.error('Build files are missing. Run: npm run build')
  process.exit(1)
}

const server = http.createServer(async (req, res) => {
  try {
    const { path, data } = await readAsset(req.url)
    const type = MIME[extname(path).toLowerCase()] || 'application/octet-stream'
    res.writeHead(200, { 'Content-Type': type, ...securityHeaders() })
    res.end(data)
  } catch (error) {
    res.writeHead(500, { 'Content-Type': 'text/plain; charset=utf-8', ...securityHeaders() })
    res.end('Unable to load XYRE Wallet.')
    console.error(error)
  }
})

const port = await listenOnAvailablePort(server)
const url = `http://${HOST}:${port}`

console.log('')
console.log('XYRE Wallet is running locally.')
console.log(`Wallet URL: ${url}`)
console.log('Close this terminal window or press Ctrl+C to stop it.')
console.log('')

openBrowser(url)

for (const signal of ['SIGINT', 'SIGTERM']) {
  process.on(signal, () => {
    server.close(() => process.exit(0))
  })
}
