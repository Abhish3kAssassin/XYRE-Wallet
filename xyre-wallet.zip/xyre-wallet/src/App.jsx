import { useCallback, useEffect, useState } from 'react'
import { QRCodeSVG } from 'qrcode.react'
import {
  Client,
  Wallet,
  isValidClassicAddress,
  xrpToDrops,
} from 'xrpl'

const MAINNET = {
  label: 'Mainnet',
  urls: [
    'wss://xrplcluster.com/',
    'wss://s1.ripple.com/',
    'wss://s2.ripple.com/',
  ],
  explorer: 'https://livenet.xrpl.org/accounts/',
}


function Icon({ name, size = 18 }) {
  const common = {
    width: size,
    height: size,
    viewBox: '0 0 24 24',
    fill: 'none',
    stroke: 'currentColor',
    strokeWidth: 1.8,
    strokeLinecap: 'round',
    strokeLinejoin: 'round',
    'aria-hidden': true,
  }

  const icons = {
    arrowUp: <><path d="M12 19V5"/><path d="m6 11 6-6 6 6"/></>,
    arrowDown: <><path d="M12 5v14"/><path d="m18 13-6 6-6-6"/></>,
    copy: <><rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></>,
    download: <><path d="M12 3v12"/><path d="m7 10 5 5 5-5"/><path d="M5 21h14"/></>,
    eye: <><path d="M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6S2 12 2 12Z"/><circle cx="12" cy="12" r="2.5"/></>,
    eyeOff: <><path d="m3 3 18 18"/><path d="M10.6 6.1A11 11 0 0 1 12 6c6.5 0 10 6 10 6a18 18 0 0 1-2.1 2.8"/><path d="M6.7 6.7C3.6 8.4 2 12 2 12s3.5 6 10 6c1.3 0 2.5-.2 3.5-.6"/></>,
    refresh: <><path d="M20 6v5h-5"/><path d="M4 18v-5h5"/><path d="M18.3 9A7 7 0 0 0 6.1 6.6L4 11"/><path d="M5.7 15A7 7 0 0 0 17.9 17.4L20 13"/></>,
    shield: <><path d="M12 22s8-3.5 8-10V5l-8-3-8 3v7c0 6.5 8 10 8 10Z"/><path d="m9 12 2 2 4-4"/></>,
    external: <><path d="M15 3h6v6"/><path d="M10 14 21 3"/><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/></>,
    logout: <><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="m16 17 5-5-5-5"/><path d="M21 12H9"/></>,
    check: <path d="m5 12 4 4L19 6"/>,
    warning: <><path d="M12 9v4"/><path d="M12 17h.01"/><path d="M10.3 3.6 1.8 18.2A2 2 0 0 0 3.5 21h17a2 2 0 0 0 1.7-2.8L13.7 3.6a2 2 0 0 0-3.4 0Z"/></>,
  }

  return <svg {...common}>{icons[name]}</svg>
}

function downloadText(filename, text) {
  const blob = new Blob([text], { type: 'text/plain;charset=utf-8' })
  const url = URL.createObjectURL(blob)
  const link = document.createElement('a')
  link.href = url
  link.download = filename
  document.body.appendChild(link)
  link.click()
  link.remove()
  URL.revokeObjectURL(url)
}

function shorten(value, start = 8, end = 7) {
  if (!value) return ''
  return `${value.slice(0, start)}…${value.slice(-end)}`
}

function formatError(error) {
  const message = error?.data?.error_message || error?.message || String(error)
  if (message.includes('actNotFound')) return 'Account is not activated yet. Fund it with XRP first.'
  if (message.includes('tecUNFUNDED_PAYMENT')) return 'Not enough spendable XRP for this payment.'
  if (message.includes('tecNO_DST_INSUF_XRP')) return 'Destination is not activated and the amount is too small to activate it.'
  return message
}

async function withClient(task) {
  let lastConnectionError

  for (const url of MAINNET.urls) {
    const client = new Client(url)

    try {
      await client.connect()
    } catch (error) {
      lastConnectionError = error
      if (client.isConnected()) await client.disconnect()
      continue
    }

    try {
      // Run the operation only once after a server connection succeeds.
      // This avoids retrying a payment on another server after submission.
      return await task(client)
    } finally {
      if (client.isConnected()) await client.disconnect()
    }
  }

  throw lastConnectionError || new Error('Unable to connect to the XRP Ledger Mainnet.')
}

export default function App() {
  const [wallet, setWallet] = useState(null)
  const [balance, setBalance] = useState('0.000000')
  const [activePanel, setActivePanel] = useState(null)
  const [showImport, setShowImport] = useState(false)
  const [importSeed, setImportSeed] = useState('')
  const [showSecrets, setShowSecrets] = useState(false)
  const [destination, setDestination] = useState('')
  const [destinationTag, setDestinationTag] = useState('')
  const [amount, setAmount] = useState('')
  const [busy, setBusy] = useState(false)
  const [message, setMessage] = useState(null)
  const [copied, setCopied] = useState('')
  const [lastTx, setLastTx] = useState(null)

  const address = wallet?.classicAddress || ''

  const networkInfo = MAINNET

  const refreshBalance = useCallback(async () => {
    if (!wallet) return
    setBusy(true)
    try {
      const value = await withClient((client) => client.getXrpBalance(wallet.classicAddress))
      setBalance(Number(value).toFixed(6))
      setMessage(null)
    } catch (error) {
      if ((error?.data?.error || '').includes('actNotFound') || (error?.message || '').includes('actNotFound')) {
        setBalance('0.000000')
      } else {
        setMessage({ type: 'error', text: formatError(error) })
      }
    } finally {
      setBusy(false)
    }
  }, [wallet])

  useEffect(() => {
    if (wallet) refreshBalance()
  }, [wallet, refreshBalance])

  const createWallet = () => {
    try {
      const newWallet = Wallet.generate()
      setWallet(newWallet)
      setShowSecrets(true)
      setActivePanel('backup')
      setMessage({ type: 'success', text: 'Wallet created. Save your recovery seed before using it.' })
    } catch (error) {
      setMessage({ type: 'error', text: formatError(error) })
    }
  }

  const importWallet = (event) => {
    event.preventDefault()
    try {
      const imported = Wallet.fromSeed(importSeed.trim())
      setWallet(imported)
      setImportSeed('')
      setShowImport(false)
      setShowSecrets(false)
      setActivePanel(null)
      setMessage({ type: 'success', text: 'Wallet imported for this browser session.' })
    } catch {
      setMessage({ type: 'error', text: 'Invalid XRP Ledger seed.' })
    }
  }

  const copy = async (text, label) => {
    await navigator.clipboard.writeText(text)
    setCopied(label)
    window.setTimeout(() => setCopied(''), 1500)
  }

  const downloadSeed = () => {
    downloadText(
      'xyre-recovery-seed.txt',
      `XYRE Wallet Recovery Seed\n\nAddress: ${wallet.classicAddress}\nSeed: ${wallet.seed}\n\nKEEP THIS FILE PRIVATE. Anyone with this seed can control your XRP.\n`,
    )
  }

  const downloadPrivateKey = () => {
    downloadText(
      'xyre-private-key.txt',
      `XYRE Wallet Private Key\n\nAddress: ${wallet.classicAddress}\nPrivate Key: ${wallet.privateKey}\n\nKEEP THIS FILE PRIVATE. Anyone with this key can sign transactions for this wallet.\n`,
    )
  }

  const downloadRecoveryKit = () => {
    downloadText(
      'xyre-wallet-recovery-kit.txt',
      `XYRE Wallet Recovery Kit\n\nAddress: ${wallet.classicAddress}\nPublic Key: ${wallet.publicKey}\nSeed: ${wallet.seed}\nPrivate Key: ${wallet.privateKey}\n\nNETWORK: XRP Ledger Mainnet\n\nSECURITY WARNING: Store this file offline and never share it. Anyone with the seed/private key can control the wallet.\n`,
    )
  }

  const sendXrp = async (event) => {
    event.preventDefault()
    if (!wallet) return

    if (!isValidClassicAddress(destination.trim())) {
      setMessage({ type: 'error', text: 'Enter a valid classic XRP address.' })
      return
    }

    const numberAmount = Number(amount)
    if (!Number.isFinite(numberAmount) || numberAmount <= 0) {
      setMessage({ type: 'error', text: 'Enter a valid XRP amount greater than 0.' })
      return
    }

    if (destinationTag && (!/^\d+$/.test(destinationTag) || Number(destinationTag) > 4294967295)) {
      setMessage({ type: 'error', text: 'Destination tag must be an integer from 0 to 4294967295.' })
      return
    }

    setBusy(true)
    setMessage({ type: 'info', text: 'Signing and submitting transaction…' })

    try {
      const payment = {
        TransactionType: 'Payment',
        Account: wallet.classicAddress,
        Destination: destination.trim(),
        Amount: xrpToDrops(amount.trim()),
      }

      if (destinationTag !== '') payment.DestinationTag = Number(destinationTag)

      const response = await withClient((client) =>
        client.submitAndWait(payment, { wallet }),
      )

      const txResult = response?.result?.meta?.TransactionResult
      if (txResult && txResult !== 'tesSUCCESS') {
        throw new Error(`Transaction finished with ${txResult}`)
      }

      const hash = response?.result?.hash || response?.result?.tx_json?.hash || ''
      setLastTx({ hash, amount, destination: destination.trim() })
      setDestination('')
      setDestinationTag('')
      setAmount('')
      setActivePanel(null)
      setMessage({ type: 'success', text: 'XRP sent and validated.' })
      await refreshBalance()
    } catch (error) {
      setMessage({ type: 'error', text: formatError(error) })
    } finally {
      setBusy(false)
    }
  }

  const logout = () => {
    setWallet(null)
    setBalance('0.000000')
    setActivePanel(null)
    setShowSecrets(false)
    setLastTx(null)
    setMessage(null)
  }

  if (!wallet) {
    return (
      <main className="landing-shell">
        <section className="landing-card">
          <div className="brand-mark" aria-hidden="true">
            <span>X</span>
          </div>
          <div className="eyebrow">XRP Ledger • Mainnet</div>
          <h1>XYRE Wallet</h1>
          <p className="landing-copy">
            A simple self-custody wallet for the XRP Ledger. Send, receive, and securely back up your keys in a local-first interface.
          </p>

          {message && <Notice message={message} />}

          {!showImport ? (
            <div className="landing-actions">
              <button className="button primary large" onClick={createWallet}>
                Create new wallet
              </button>
              <button className="button ghost large" onClick={() => setShowImport(true)}>
                Import recovery seed
              </button>
            </div>
          ) : (
            <form className="import-form" onSubmit={importWallet}>
              <label>
                Recovery seed
                <input
                  autoFocus
                  type="password"
                  value={importSeed}
                  onChange={(e) => setImportSeed(e.target.value)}
                  placeholder="s… or sEd…"
                  autoComplete="off"
                  required
                />
              </label>
              <div className="inline-actions">
                <button className="button primary" type="submit">Import wallet</button>
                <button className="button ghost" type="button" onClick={() => setShowImport(false)}>Cancel</button>
              </div>
            </form>
          )}

          <div className="landing-note">
            <Icon name="shield" />
            <span>Keys stay in memory and are cleared when you close or reload the page.</span>
          </div>
        </section>
      </main>
    )
  }

  return (
    <main className="app-shell">
      <header className="topbar">
        <div className="brand-row">
          <div className="brand-mark small"><span>X</span></div>
          <div>
            <div className="brand-title">XYRE Wallet</div>
            <div className="brand-subtitle">XRP Ledger Mainnet • self-custody</div>
          </div>
        </div>

        <div className="topbar-actions">
          <div className="network-toggle" aria-label="Network">
            <span className="network-static">
              <span className="status-dot main" />
              Mainnet
            </span>
          </div>
          <button className="icon-button" onClick={logout} title="Lock wallet" aria-label="Lock wallet">
            <Icon name="logout" />
          </button>
        </div>
      </header>

      <section className="content">
        {message && <Notice message={message} onClose={() => setMessage(null)} />}

        <div className="mainnet-warning">
          <Icon name="warning" />
          <span>Mainnet uses real XRP. Verify the destination, destination tag, and amount before sending.</span>
        </div>

        <section className="balance-card">
          <div className="balance-topline">
            <span>Available balance</span>
            <button className="text-button" onClick={refreshBalance} disabled={busy}>
              <Icon name="refresh" size={15} /> Refresh
            </button>
          </div>
          <div className="balance-value">
            <span>{balance}</span>
            <small>XRP</small>
          </div>
          <div className="address-row">
            <code>{shorten(address, 10, 8)}</code>
            <button className="icon-button compact" onClick={() => copy(address, 'address')} title="Copy address">
              {copied === 'address' ? <Icon name="check" /> : <Icon name="copy" />}
            </button>
            <a className="icon-button compact" href={`${networkInfo.explorer}${address}`} target="_blank" rel="noreferrer" title="Open explorer">
              <Icon name="external" />
            </a>
          </div>

          <div className="wallet-actions">
            <button className="action-button" onClick={() => setActivePanel('send')}>
              <span className="action-icon"><Icon name="arrowUp" /></span>
              <span>Send</span>
            </button>
            <button className="action-button" onClick={() => setActivePanel('receive')}>
              <span className="action-icon"><Icon name="arrowDown" /></span>
              <span>Receive</span>
            </button>
            <button className="action-button" onClick={() => { setActivePanel('backup'); setShowSecrets(false) }}>
              <span className="action-icon"><Icon name="shield" /></span>
              <span>Backup</span>
            </button>
          </div>
        </section>

        <section className="grid">
          <div className="card account-card">
            <div className="card-heading">
              <div>
                <p className="kicker">Account</p>
                <h2>Your XRP address</h2>
              </div>
              <span className="network-pill main"><span className="status-dot main" /> Mainnet</span>
            </div>
            <div className="address-box">
              <code>{address}</code>
              <button className="button ghost mini" onClick={() => copy(address, 'full-address')}>
                {copied === 'full-address' ? 'Copied' : 'Copy'}
              </button>
            </div>
            <p className="muted">Share only this public address to receive XRP on Mainnet.</p>

          </div>

          <div className="card security-card">
            <div className="card-heading">
              <div>
                <p className="kicker">Security</p>
                <h2>Local-session keys</h2>
              </div>
              <span className="security-badge"><Icon name="shield" size={16} /> In memory</span>
            </div>
            <p className="muted roomy">
              This wallet does not store your recovery seed in localStorage or a database. Reloading the page locks the wallet.
            </p>
            <button className="button ghost" onClick={() => setActivePanel('backup')}>View backup options</button>
          </div>
        </section>

        {lastTx && (
          <section className="card transaction-card">
            <div className="transaction-icon"><Icon name="check" /></div>
            <div className="transaction-info">
              <strong>Payment sent</strong>
              <span>{lastTx.amount} XRP → {shorten(lastTx.destination)}</span>
            </div>
            {lastTx.hash && <code>{shorten(lastTx.hash, 7, 7)}</code>}
          </section>
        )}
      </section>

      {activePanel && (
        <div className="modal-backdrop" onMouseDown={(e) => e.target === e.currentTarget && setActivePanel(null)}>
          <div className="modal">
            <button className="modal-close" onClick={() => setActivePanel(null)} aria-label="Close">×</button>

            {activePanel === 'send' && (
              <>
                <p className="kicker">Payment</p>
                <h2>Send XRP</h2>
                <p className="muted modal-copy">Transactions are signed locally with the wallet currently open in this session.</p>
                <form className="form-stack" onSubmit={sendXrp}>
                  <label>
                    Destination address
                    <input value={destination} onChange={(e) => setDestination(e.target.value)} placeholder="r…" required />
                  </label>
                  <div className="form-row">
                    <label>
                      Amount
                      <div className="input-suffix">
                        <input inputMode="decimal" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="0.00" required />
                        <span>XRP</span>
                      </div>
                    </label>
                    <label>
                      Destination tag <span className="optional">optional</span>
                      <input inputMode="numeric" value={destinationTag} onChange={(e) => setDestinationTag(e.target.value)} placeholder="123456" />
                    </label>
                  </div>
                  <button className="button primary large" type="submit" disabled={busy}>
                    {busy ? 'Sending…' : 'Send on Mainnet'}
                  </button>
                </form>
              </>
            )}

            {activePanel === 'receive' && (
              <div className="receive-panel">
                <p className="kicker">Deposit</p>
                <h2>Receive XRP</h2>
                <p className="muted modal-copy">Send XRP to this address on XRP Ledger Mainnet.</p>
                <div className="qr-wrap">
                  <QRCodeSVG value={address} size={190} level="M" marginSize={2} />
                </div>
                <div className="receive-address">
                  <code>{address}</code>
                  <button className="button secondary" onClick={() => copy(address, 'receive')}>
                    {copied === 'receive' ? 'Copied' : 'Copy address'}
                  </button>
                </div>
              </div>
            )}

            {activePanel === 'backup' && (
              <div className="backup-panel">
                <p className="kicker">Recovery</p>
                <h2>Back up your wallet</h2>
                <div className="danger-note">
                  <Icon name="warning" />
                  <span>Never share your recovery seed or private key. Anyone who has either can control this wallet.</span>
                </div>

                <SecretField
                  label="Recovery seed"
                  value={wallet.seed || ''}
                  visible={showSecrets}
                  onCopy={() => copy(wallet.seed || '', 'seed')}
                  copied={copied === 'seed'}
                />
                <SecretField
                  label="Private key"
                  value={wallet.privateKey}
                  visible={showSecrets}
                  onCopy={() => copy(wallet.privateKey, 'private')}
                  copied={copied === 'private'}
                />

                <button className="button ghost reveal" onClick={() => setShowSecrets((value) => !value)}>
                  <Icon name={showSecrets ? 'eyeOff' : 'eye'} />
                  {showSecrets ? 'Hide secrets' : 'Reveal secrets'}
                </button>

                <div className="download-grid">
                  <button className="download-button" onClick={downloadSeed}>
                    <Icon name="download" />
                    <span><strong>Recovery seed</strong><small>TXT file</small></span>
                  </button>
                  <button className="download-button" onClick={downloadPrivateKey}>
                    <Icon name="download" />
                    <span><strong>Private key</strong><small>TXT file</small></span>
                  </button>
                </div>
                <button className="button primary full" onClick={downloadRecoveryKit}>
                  <Icon name="download" /> Download full recovery kit
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </main>
  )
}

function Notice({ message, onClose }) {
  return (
    <div className={`notice ${message.type || 'info'}`}>
      <span>{message.text}</span>
      {onClose && <button onClick={onClose} aria-label="Dismiss">×</button>}
    </div>
  )
}

function SecretField({ label, value, visible, onCopy, copied }) {
  return (
    <div className="secret-field">
      <span>{label}</span>
      <div>
        <code>{visible ? value : '•'.repeat(Math.min(36, Math.max(20, value.length)))}</code>
        <button className="icon-button compact" onClick={onCopy} title={`Copy ${label}`}>
          {copied ? <Icon name="check" /> : <Icon name="copy" />}
        </button>
      </div>
    </div>
  )
}
